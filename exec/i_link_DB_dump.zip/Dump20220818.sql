-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: i7e102.p.ssafy.io    Database: i_link
-- ------------------------------------------------------
-- Server version	8.0.29

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `albums`
--

DROP TABLE IF EXISTS `albums`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `albums` (
  `album_no` int NOT NULL AUTO_INCREMENT,
  `group_no` int NOT NULL,
  `album_url` varchar(500) NOT NULL,
  PRIMARY KEY (`album_no`),
  KEY `ALBUM_GROUP_FK_idx` (`group_no`),
  CONSTRAINT `albums_ibfk_1` FOREIGN KEY (`group_no`) REFERENCES `groups` (`group_no`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `albums`
--

LOCK TABLES `albums` WRITE;
/*!40000 ALTER TABLE `albums` DISABLE KEYS */;
/*!40000 ALTER TABLE `albums` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `centers`
--

DROP TABLE IF EXISTS `centers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `centers` (
  `center_no` int NOT NULL AUTO_INCREMENT,
  `center_name` varchar(50) NOT NULL,
  `center_addr` varchar(200) NOT NULL,
  `center_tel` varchar(20) DEFAULT NULL,
  `master_no` int NOT NULL,
  PRIMARY KEY (`center_no`),
  UNIQUE KEY `master_no_UNIQUE` (`master_no`),
  KEY `CENTER_USER_FK_idx` (`master_no`),
  CONSTRAINT `centers_ibfk_1` FOREIGN KEY (`master_no`) REFERENCES `users` (`user_no`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `centers`
--

LOCK TABLES `centers` WRITE;
/*!40000 ALTER TABLE `centers` DISABLE KEYS */;
INSERT INTO `centers` VALUES (1,'아이링크 유치원','부산 강서구 녹산산단77로 6 (송정동) 7','051-256-1578',1);
/*!40000 ALTER TABLE `centers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `files`
--

DROP TABLE IF EXISTS `files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `files` (
  `file_no` int NOT NULL AUTO_INCREMENT,
  `notice_no` int NOT NULL,
  `file_name` varchar(100) NOT NULL,
  `file_size` int NOT NULL,
  `file_type` varchar(255) NOT NULL,
  `file_location` varchar(255) NOT NULL,
  PRIMARY KEY (`file_no`),
  KEY `FILE_NOTICE_FK_idx` (`notice_no`),
  CONSTRAINT `files_ibfk_1` FOREIGN KEY (`notice_no`) REFERENCES `notices` (`notice_no`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `files`
--

LOCK TABLES `files` WRITE;
/*!40000 ALTER TABLE `files` DISABLE KEYS */;
INSERT INTO `files` VALUES (1,1,'unknown.png',232642,'image/png','/uploads/attachment/1660791418149.png');
/*!40000 ALTER TABLE `files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `groups`
--

DROP TABLE IF EXISTS `groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `groups` (
  `group_no` int NOT NULL AUTO_INCREMENT,
  `center_no` int NOT NULL,
  `group_name` varchar(50) NOT NULL,
  PRIMARY KEY (`group_no`),
  KEY `GROUP_CENTER_FK_idx` (`center_no`),
  CONSTRAINT `groups_ibfk_1` FOREIGN KEY (`center_no`) REFERENCES `centers` (`center_no`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `groups`
--

LOCK TABLES `groups` WRITE;
/*!40000 ALTER TABLE `groups` DISABLE KEYS */;
INSERT INTO `groups` VALUES (1,1,'햇님반'),(2,1,'달님반');
/*!40000 ALTER TABLE `groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `kids`
--

DROP TABLE IF EXISTS `kids`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `kids` (
  `kid_no` int NOT NULL AUTO_INCREMENT,
  `kid_name` varchar(20) NOT NULL,
  `kid_birth` date DEFAULT NULL,
  `kid_gender` varchar(1) DEFAULT NULL,
  `kid_stamp` int NOT NULL DEFAULT '0',
  `kid_profile_url` varchar(255) DEFAULT NULL,
  `kid_memo` varchar(255) DEFAULT NULL,
  `parents_no` int NOT NULL,
  `group_no` int DEFAULT NULL,
  `center_no` int DEFAULT NULL,
  `kid_state` varchar(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`kid_no`),
  KEY `KID_GROUP_FK_idx` (`group_no`),
  KEY `KID_USER_FK_idx` (`parents_no`),
  KEY `KID_CENTER_FK_idx` (`center_no`),
  CONSTRAINT `kids_ibfk_1` FOREIGN KEY (`parents_no`) REFERENCES `users` (`user_no`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `kids_ibfk_2` FOREIGN KEY (`group_no`) REFERENCES `groups` (`group_no`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `kids_ibfk_3` FOREIGN KEY (`center_no`) REFERENCES `centers` (`center_no`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kids`
--

LOCK TABLES `kids` WRITE;
/*!40000 ALTER TABLE `kids` DISABLE KEYS */;
INSERT INTO `kids` VALUES (1,'이소영','2017-07-20','M',3,'/uploads/profile/1660791297766.png',NULL,2,1,1,'1'),(2,'송형근','2016-06-22','F',0,'/uploads/profile/1660791820501.png',NULL,4,1,1,'1'),(3,'안영원','2018-06-05','M',0,'/uploads/profile/1660791850786.png',NULL,4,1,1,'1'),(4,'김문희','2018-08-10','M',0,'/uploads/profile/1660791872976.png',NULL,4,1,1,'1'),(5,'박준영','2018-02-17','M',2,'/uploads/profile/1660791994568.png',NULL,2,1,1,'1'),(6,'김지우','2018-07-12','M',0,NULL,NULL,6,NULL,NULL,'0'),(7,'강민재','2022-08-02',NULL,1,'/uploads/profile/1660807758507.png',NULL,2,NULL,1,'0');
/*!40000 ALTER TABLE `kids` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `meals`
--

DROP TABLE IF EXISTS `meals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `meals` (
  `meal_no` int NOT NULL AUTO_INCREMENT,
  `center_no` int NOT NULL,
  `meal_content` varchar(255) DEFAULT NULL,
  `snack_content` varchar(255) DEFAULT NULL,
  `meal_date` date NOT NULL,
  PRIMARY KEY (`meal_no`),
  KEY `MEAL_CENTER_FK_idx` (`center_no`),
  CONSTRAINT `meals_ibfk_1` FOREIGN KEY (`center_no`) REFERENCES `centers` (`center_no`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `meals`
--

LOCK TABLES `meals` WRITE;
/*!40000 ALTER TABLE `meals` DISABLE KEYS */;
INSERT INTO `meals` VALUES (1,1,'기장밥,쇠고기미역국,새송이메추리알조림,콩나물냉채,배추김치,복숭아','마늘바게트,배도라지주스','2022-08-01'),(2,1,'보리밥,순두부찌개,로제스파게티,야채계란찜,열무김치,사과','미니와플,파인애플','2022-08-02'),(3,1,'한우야채볶음밥,물만두국,블루베리샐러드,수제치킨까스,깍두기','슈크림빵,감귤주스','2022-08-03'),(4,1,'흑미밥,근대된장국,돈채콩나물볶음,고등어마요네즈구이,배추김치,대추방울토마토','토핑요거트, 큐브치즈','2022-08-04'),(5,1,'차수수밥,수제비국,도토리묵야채무침,불고기떡볶이,깍두기,파인애플','갈비만두,사과주스','2022-08-05'),(6,1,'기장밥,닭곰탕,두부야채조림,피망감자채볶음,볶음김치,생망고','기정떡,식혜','2022-08-08'),(7,1,'율무밥,해물된장찌개,숙주미나리나물,치즈닭갈비,깍두기,파인애플','미니바나나케이크,딸기라떼','2022-08-09'),(8,1,'차수수밥,등뼈감자탕,마늘쫑어묵볶음,게살오이냉채,백김치,수박','무항생제단호박핫도그,비타민청포도주스','2022-08-10'),(9,1,'혼합잡곡밥,오징어무국,한우찹스테이크,브로콜리맛살볶음,배추김치,자두','화이트슈,요구르트','2022-08-11'),(10,1,'옥수수밥,꽃게된장찌개,시금치무침,오삼불고기,배추김치,멜론','딸기롤케이크,ABC주스','2022-08-12'),(11,1,'광복절 휴원',NULL,'2022-08-15'),(12,1,'강황밥,부추계란국,황도샐러드,칸쇼새우,깍두기,키위','구슬아이스크림,찹쌀유과','2022-08-16'),(13,1,'흑미밥,참치김치찌개,푸실리샐러드,두부스테이크,백김치,사과','우리밀칼슘식빵,소화가잘되는흰우유','2022-08-17'),(15,1,'흑미밥,소고기미역국,비엔나야채볶음,배추김치,맛김','마카롱,딸기요거트','2022-08-18');
/*!40000 ALTER TABLE `meals` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `memos`
--

DROP TABLE IF EXISTS `memos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `memos` (
  `memo_no` int NOT NULL AUTO_INCREMENT,
  `group_no` int NOT NULL,
  `memo_content` varchar(255) NOT NULL,
  `memo_date` date NOT NULL,
  PRIMARY KEY (`memo_no`),
  KEY `MEMO_GROUP_FK_idx` (`group_no`),
  CONSTRAINT `memos_ibfk_1` FOREIGN KEY (`group_no`) REFERENCES `groups` (`group_no`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `memos`
--

LOCK TABLES `memos` WRITE;
/*!40000 ALTER TABLE `memos` DISABLE KEYS */;
INSERT INTO `memos` VALUES (1,1,'지점토,실내화','2022-08-16'),(2,1,'실로폰,물체 주머니','2022-08-17'),(3,1,'학종이,물풀','2022-08-18'),(4,2,'크레파스,스케치북','2022-08-16'),(5,2,'색종이','2022-08-17'),(6,1,'색종이','2022-08-19');
/*!40000 ALTER TABLE `memos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notices`
--

DROP TABLE IF EXISTS `notices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notices` (
  `notice_no` int NOT NULL AUTO_INCREMENT,
  `center_no` int NOT NULL,
  `notice_title` varchar(100) NOT NULL,
  `notice_content` varchar(500) NOT NULL,
  `notice_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`notice_no`),
  KEY `NOTICE_CENTER_FK_idx` (`center_no`),
  CONSTRAINT `notices_ibfk_1` FOREIGN KEY (`center_no`) REFERENCES `centers` (`center_no`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notices`
--

LOCK TABLES `notices` WRITE;
/*!40000 ALTER TABLE `notices` DISABLE KEYS */;
INSERT INTO `notices` VALUES (1,1,'2022학년도 아이링크 유치원 신입생 유아모집 공고','8월 가정통신문','2022-08-18 11:56:58');
/*!40000 ALTER TABLE `notices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quiz`
--

DROP TABLE IF EXISTS `quiz`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `quiz` (
  `quiz_no` int NOT NULL AUTO_INCREMENT,
  `quiz_writer` int NOT NULL,
  `group_no` int NOT NULL,
  `quiz_content` varchar(100) DEFAULT NULL,
  `quiz_sel_1` varchar(50) DEFAULT NULL,
  `quiz_sel_2` varchar(50) DEFAULT NULL,
  `quiz_sel_3` varchar(50) DEFAULT NULL,
  `quiz_sel_4` varchar(50) DEFAULT NULL,
  `quiz_ans` int DEFAULT NULL,
  `quiz_date` date DEFAULT NULL,
  PRIMARY KEY (`quiz_no`),
  KEY `QUIZ_USER_FK_idx` (`quiz_writer`),
  KEY `QUIZ_GROUP_FK_idx` (`group_no`),
  CONSTRAINT `quiz_ibfk_1` FOREIGN KEY (`quiz_writer`) REFERENCES `users` (`user_no`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `quiz_ibfk_2` FOREIGN KEY (`group_no`) REFERENCES `groups` (`group_no`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quiz`
--

LOCK TABLES `quiz` WRITE;
/*!40000 ALTER TABLE `quiz` DISABLE KEYS */;
INSERT INTO `quiz` VALUES (1,3,1,'사과는 무엇일까요?',NULL,NULL,NULL,NULL,NULL,'2022-08-18'),(3,3,1,'이 서비스의 이름은?','아이노트','아이퀴즈','아이링크','싸피',NULL,NULL);
/*!40000 ALTER TABLE `quiz` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quiz_images`
--

DROP TABLE IF EXISTS `quiz_images`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `quiz_images` (
  `img_no` int NOT NULL AUTO_INCREMENT,
  `quiz_content_url` varchar(255) DEFAULT NULL,
  `quiz_sel_1_url` varchar(255) DEFAULT NULL,
  `quiz_sel_2_url` varchar(255) DEFAULT NULL,
  `quiz_sel_3_url` varchar(255) DEFAULT NULL,
  `quiz_sel_4_url` varchar(255) DEFAULT NULL,
  `quiz_no` int NOT NULL,
  PRIMARY KEY (`img_no`),
  KEY `IMAGE_QUIZ_FK_idx` (`quiz_no`) /*!80000 INVISIBLE */,
  CONSTRAINT `quiz_images_ibfk_1` FOREIGN KEY (`quiz_no`) REFERENCES `quiz` (`quiz_no`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quiz_images`
--

LOCK TABLES `quiz_images` WRITE;
/*!40000 ALTER TABLE `quiz_images` DISABLE KEYS */;
INSERT INTO `quiz_images` VALUES (5,NULL,'/uploads/quiz/1660797901671.png','/uploads/quiz/1660797901738.png','/uploads/quiz/1660797901750.png','/uploads/quiz/1660797901752.png',1);
/*!40000 ALTER TABLE `quiz_images` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quiz_results`
--

DROP TABLE IF EXISTS `quiz_results`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `quiz_results` (
  `result_no` int NOT NULL AUTO_INCREMENT,
  `quiz_ans` int NOT NULL,
  `kid_no` int NOT NULL,
  `quiz_no` int NOT NULL,
  PRIMARY KEY (`result_no`),
  KEY `RESULT_KID_FK_idx` (`kid_no`),
  KEY `RESULT_QUIZ_FK_idx` (`quiz_no`),
  CONSTRAINT `quiz_results_ibfk_1` FOREIGN KEY (`kid_no`) REFERENCES `kids` (`kid_no`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `quiz_results_ibfk_2` FOREIGN KEY (`quiz_no`) REFERENCES `quiz` (`quiz_no`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quiz_results`
--

LOCK TABLES `quiz_results` WRITE;
/*!40000 ALTER TABLE `quiz_results` DISABLE KEYS */;
INSERT INTO `quiz_results` VALUES (1,1,1,1),(2,1,5,1),(3,4,1,1),(4,4,5,1),(5,1,1,1),(6,1,1,1);
/*!40000 ALTER TABLE `quiz_results` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `report_types`
--

DROP TABLE IF EXISTS `report_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `report_types` (
  `report_type` int NOT NULL AUTO_INCREMENT,
  `type_name` varchar(10) NOT NULL,
  PRIMARY KEY (`report_type`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `report_types`
--

LOCK TABLES `report_types` WRITE;
/*!40000 ALTER TABLE `report_types` DISABLE KEYS */;
INSERT INTO `report_types` VALUES (1,'등·하원'),(2,'교우 관계'),(3,'음식 관련'),(4,'약'),(5,'수면'),(6,'기타');
/*!40000 ALTER TABLE `report_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reports`
--

DROP TABLE IF EXISTS `reports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reports` (
  `report_no` int NOT NULL AUTO_INCREMENT,
  `kid_no` int NOT NULL,
  `report_writer` int NOT NULL,
  `report_type` int NOT NULL,
  `report_content` varchar(500) NOT NULL,
  `report_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`report_no`),
  KEY `REPORT_KID_FK_idx` (`kid_no`),
  KEY `REPORT_USER_FK_idx` (`report_writer`),
  KEY `REPORT_TYPE_FK_idx` (`report_type`),
  CONSTRAINT `reports_ibfk_1` FOREIGN KEY (`kid_no`) REFERENCES `kids` (`kid_no`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `reports_ibfk_2` FOREIGN KEY (`report_writer`) REFERENCES `users` (`user_no`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `reports_ibfk_3` FOREIGN KEY (`report_type`) REFERENCES `report_types` (`report_type`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reports`
--

LOCK TABLES `reports` WRITE;
/*!40000 ALTER TABLE `reports` DISABLE KEYS */;
INSERT INTO `reports` VALUES (1,1,2,1,'개별 하원할게요. 15시쯤 데리러 가겠습니다.','2022-08-18 14:07:56'),(2,1,2,6,'애가 더위를 많이 탑니다. 실외 행동 자제 부탁드려요.','2022-08-18 14:10:29'),(3,1,2,4,'키크는약 식후 30분에 꼭 먹여주세요.','2022-08-18 14:10:57'),(4,2,4,1,'08/19 금요일에 하루 여행갈 계획이라 등원 안합니다.','2022-08-18 14:13:15');
/*!40000 ALTER TABLE `reports` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `surveys`
--

DROP TABLE IF EXISTS `surveys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `surveys` (
  `survey_no` int NOT NULL AUTO_INCREMENT,
  `kid_no` int NOT NULL,
  `survey_result` varchar(1) NOT NULL,
  `survey_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`survey_no`),
  KEY `SURVEY_KID_FK_idx` (`kid_no`),
  CONSTRAINT `surveys_ibfk_1` FOREIGN KEY (`kid_no`) REFERENCES `kids` (`kid_no`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `surveys`
--

LOCK TABLES `surveys` WRITE;
/*!40000 ALTER TABLE `surveys` DISABLE KEYS */;
INSERT INTO `surveys` VALUES (1,1,'4','2022-08-18 17:07:08'),(2,7,'4','2022-08-18 17:07:37'),(3,5,'4','2022-08-18 17:30:45'),(4,1,'4','2022-08-18 17:33:42'),(5,5,'4','2022-08-18 17:34:52'),(6,1,'4','2022-08-18 17:35:12'),(7,1,'4','2022-08-18 17:37:02');
/*!40000 ALTER TABLE `surveys` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_types`
--

DROP TABLE IF EXISTS `user_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_types` (
  `user_type` int NOT NULL AUTO_INCREMENT,
  `type_name` varchar(10) NOT NULL,
  PRIMARY KEY (`user_type`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_types`
--

LOCK TABLES `user_types` WRITE;
/*!40000 ALTER TABLE `user_types` DISABLE KEYS */;
INSERT INTO `user_types` VALUES (1,'원장'),(2,'교사'),(3,'학부모');
/*!40000 ALTER TABLE `user_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `user_no` int NOT NULL AUTO_INCREMENT,
  `user_type` int NOT NULL,
  `user_email` varchar(50) NOT NULL,
  `user_pw` varchar(255) NOT NULL,
  `user_name` varchar(20) NOT NULL,
  `user_phone` varchar(20) DEFAULT NULL,
  `user_profile_url` varchar(255) DEFAULT NULL,
  `group_no` int DEFAULT NULL,
  `center_no` int DEFAULT NULL,
  PRIMARY KEY (`user_no`),
  UNIQUE KEY `user_email_UNIQUE` (`user_email`),
  KEY `USER_CENTER_FK_idx` (`center_no`),
  KEY `USER_TYPE_FK_idx` (`user_type`),
  KEY `USER_GROUP_FK_idx` (`group_no`),
  CONSTRAINT `users_ibfk_1` FOREIGN KEY (`user_type`) REFERENCES `user_types` (`user_type`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `users_ibfk_2` FOREIGN KEY (`group_no`) REFERENCES `groups` (`group_no`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `users_ibfk_3` FOREIGN KEY (`center_no`) REFERENCES `centers` (`center_no`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,1,'master@example.com','$2a$10$CHHzgcOE.Ad.1s3V/DmpKOAfNUyk22DAzymJtraWcuNN2mbxTEGC.','김국진','010-8454-7843','/uploads/profile/1660791158569.png',NULL,1),(2,3,'parents@example.com','$2a$10$i7a9VXBkac1QV1FV7gflOOyTjPdSOValt6Pa4r9tn8QeTdAaclvAy','배지우','010-7645-8475','/uploads/profile/1660791061869.png',NULL,NULL),(3,2,'teacher@example.com','$2a$10$pzJOdSPtd1oPLk2xHIUcm.4aKxybd5Pb6IkX23rQjpYnmJiUvePG2','안정현','010-2245-7984','/uploads/profile/1660791085361.png',1,1),(4,3,'parents2@example.com','$2a$10$WYxsEFvlOUDKY948j7wFf.hJynuM88HJgzm5WwE19d4TSxVPbdmDa','강민재','010-7543-6548','/uploads/profile/1660791794014.png',NULL,NULL),(5,1,'tester@example.com','$2a$10$i9Kz6M1hwm..L/yOpwmAVewdyJs0q2F5sbVxUpE7WYA3MWjQQxe7q','테스터','010-1234-1234',NULL,NULL,NULL),(6,3,'jiwooparents@naver.com','$2a$10$a7iZwH4RifiS7CRDFIXEE.xcQTIZSD/A.7BUvNjw46vBdbnjNmeZ.','지우부모','010-4791-5385',NULL,NULL,NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-18 18:01:23
